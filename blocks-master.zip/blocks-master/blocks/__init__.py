"""The blocks library for parametrized Theano ops."""
import blocks.version
__version__ = blocks.version.version
