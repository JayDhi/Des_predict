Configuration
=============

.. automodule:: blocks.config

.. autoclass:: ConfigurationError
   :show-inheritance:
