Brick selectors
===============

.. automodule:: blocks.select
    :members:
    :undoc-members:
    :show-inheritance:
