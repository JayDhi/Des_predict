.. _utils:

Common Utilities
================

.. automodule:: blocks.utils.utils
    :members:
    :undoc-members:
    :show-inheritance:


Theano Utilities
================

.. automodule:: blocks.utils.theano_utils
    :members:
    :undoc-members:
    :show-inheritance:
