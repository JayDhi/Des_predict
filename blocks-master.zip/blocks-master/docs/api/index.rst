API Reference
=============

.. warning::

   This API reference is currently nothing but a dump of docstrings, ordered
   alphabetically.

The API reference contains detailed descriptions of the different end-user
classes, functions, methods, etc. you will need to work with Blocks.

.. note::

   This API reference only contains *end-user* documentation. If you are
   looking to hack away at Blocks' internals, you will find more detailed
   comments in the source code.

.. toctree::
   :glob:

   *
