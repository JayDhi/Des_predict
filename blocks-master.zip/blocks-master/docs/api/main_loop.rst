.. _main:

Main loop
=========

.. automodule:: blocks.main_loop
    :members:
    :undoc-members:
    :show-inheritance:
