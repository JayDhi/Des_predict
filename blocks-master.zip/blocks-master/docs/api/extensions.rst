Extensions
==========

.. automodule:: blocks.extensions
    :members:
    :undoc-members:
    :show-inheritance:

Monitoring extensions
---------------------

.. automodule:: blocks.extensions.monitoring
    :members:
    :undoc-members:
    :show-inheritance:

Training
--------

.. automodule:: blocks.extensions.training
    :members:
    :undoc-members:
    :show-inheritance:

Serialization
-------------

.. automodule:: blocks.extensions.saveload
    :members:
    :undoc-members:
    :show-inheritance:
