.. _initialization:

Parameter initialization
========================

.. automodule:: blocks.initialization
    :members:
    :undoc-members:
    :show-inheritance:
