.. _filter:

Filter
======

.. automodule:: blocks.filter
    :members:
    :undoc-members:
    :show-inheritance:
