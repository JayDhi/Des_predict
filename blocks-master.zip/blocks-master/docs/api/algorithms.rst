Algorithms
==========

.. automodule:: blocks.algorithms
    :members:
    :undoc-members:
    :show-inheritance:
