Serialization
=============

.. automodule:: blocks.serialization
    :members:
    :undoc-members:
    :show-inheritance:
