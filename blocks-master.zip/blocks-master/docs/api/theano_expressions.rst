.. _theano_expressions:

Theano expressions
==================

.. automodule:: blocks.theano_expressions
    :members:
    :undoc-members:
    :show-inheritance:
