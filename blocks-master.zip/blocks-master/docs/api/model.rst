Model
=====

.. automodule:: blocks.model
    :members:
    :undoc-members:
    :show-inheritance:
