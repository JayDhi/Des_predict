.. _graph:

Computational graph
===================

.. automodule:: blocks.graph
    :members:
    :undoc-members:
    :show-inheritance:
