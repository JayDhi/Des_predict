import fuel.version
from fuel.config_parser import config  # noqa

__version__ = fuel.version.version
