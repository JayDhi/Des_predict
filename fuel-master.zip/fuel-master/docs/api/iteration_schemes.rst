Iteration schemes
=================

.. automodule:: fuel.schemes
    :members:
    :undoc-members:
    :show-inheritance:

