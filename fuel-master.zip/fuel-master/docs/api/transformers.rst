Transformers
============

General transformers
--------------------

.. automodule:: fuel.transformers.defaults
    :members:
    :undoc-members:
    :show-inheritance:

Transformers for image
----------------------

.. automodule:: fuel.transformers.image
    :members:
    :undoc-members:
    :show-inheritance:

Transformers for sequences
--------------------------

.. automodule:: fuel.transformers.sequences
    :members:
    :undoc-members:
    :show-inheritance:

Other
-----

.. automodule:: fuel.transformers
    :members:
    :undoc-members:
    :show-inheritance:
