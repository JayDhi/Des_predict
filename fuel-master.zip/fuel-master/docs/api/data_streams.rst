Data streams
============

.. automodule:: fuel.streams
    :members:
    :undoc-members:
    :show-inheritance:
