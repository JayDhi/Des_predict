API Reference
=============

.. warning::

   This API reference is currently nothing but a dump of docstrings, ordered
   alphabetically.

.. toctree::
    :glob:

    *
